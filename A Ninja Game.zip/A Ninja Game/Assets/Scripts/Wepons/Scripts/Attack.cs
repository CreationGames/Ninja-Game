﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Attack : MonoBehaviour
{
    public float health = 100;

    void OnTriggerEnter(Collider col)
    {
        Wepon theWepon = col.GetComponent<Wepon>();
        if (theWepon != null)
        {
            damageing(theWepon.damage);
        }      
    }

    public void damageing(float amount)
    {
        Debug.Log("Hit");
        health -= amount;
        
        if (health <= 0f)
        {
            Destroy(gameObject);
        }
    }

}
