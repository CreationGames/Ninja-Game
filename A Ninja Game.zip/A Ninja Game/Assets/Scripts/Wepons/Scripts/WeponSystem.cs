﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class WeponSystem : MonoBehaviour
{
    public GameObject broom;
    public GameObject NinjaStar;
    public GameObject Needle;
    public GameObject knife;
    public Transform shootPoint;
    public float speed = 100f;
    public float distance = 10f;
    

    private PickUpSystem pks;
    private Wepon wp;
    private Rigidbody rb;
    private Animator broomAni;
    private Animator knifeAni;

    private float rspeed = 90f;
    private float spin = 180f;
    

    // Start is called before the first frame update
    void Start()
    {
       pks = FindObjectOfType<PickUpSystem>();
       wp = broom.GetComponent<Wepon>();
        knifeAni = knife.GetComponent<Animator>();
        broomAni = broom.GetComponent<Animator>();
    }

    // Update is called once per frame
    void Update()
    {

        if (Input.GetButtonDown("Fire1"))
        {
            if (pks.pickedItem != null)
            {
               if (pks.pickedItem.name.Equals ("NinjaBlade"))
               {
                 starThrow();
               }else if (pks.pickedItem.name.Equals ("broomStick"))
               {
                 BroomHit();
               }else if (pks.pickedItem.name.Equals ("Cone"))
               {
                  Throw();
               }else if (pks.pickedItem.name.Equals ("Knife"))
               {
                  Knife();
               }
            }else
            {
               
            }
          
        }


        if (Input.GetButtonUp("Fire1"))
        {
            
            if (pks.pickedItem != null)
            {
                if (pks.pickedItem.name.Equals ("broomStick"))
                {
                  BroomUnhit();
                }else if(pks.pickedItem.name.Equals ("Knife"))
                {
                    unKnife();
                }
            }
            
            
        }
    }

    public void starThrow()
    {
        GameObject star = Instantiate(NinjaStar,shootPoint.position, Quaternion.identity);
        rb = star.GetComponent<Rigidbody>();
        rb.AddForce(shootPoint.forward * speed* distance * Time.deltaTime);
    }
    public void BroomHit()
    {
        wp.damage = 50f;
        broomAni.SetBool("isHitting",true);

    }

    public void BroomUnhit()
    {
        broomAni.SetBool("isHitting",false);
        wp.damage = 0f;
    }

    public void Throw()
    {
        GameObject needle = Instantiate(Needle,shootPoint.position, Quaternion.identity);
        Rigidbody rab = needle.GetComponent<Rigidbody>();
        rab.AddForce(shootPoint.forward * speed* distance * Time.deltaTime);
        needle.transform.localRotation = shootPoint.rotation;
    }

    public void Knife()
    {
        knifeAni.SetBool("kThrow", true);
    }

    public void unKnife()
    {
        knifeAni.SetBool("kThrow", false);
    }


}
