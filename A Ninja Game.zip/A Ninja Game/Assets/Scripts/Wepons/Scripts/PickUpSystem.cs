﻿using UnityEngine;
/// <summary>
/// Simple example of Grabbing system.
/// </summary> 

public class PickUpSystem : MonoBehaviour
{

    public Transform refer;
    public Transform knifePosition;
    // Reference to the character camera.
    [SerializeField]
    private Camera characterCamera;
    // Reference to the slot for holding picked item.
    [SerializeField]
    private Transform slot;
    // Reference to the currently held item.
    public  PickableItem pickedItem;
    /// <summary>
    /// Method called very frame.
    /// </summary>
    private void Update ()
    {
        // Execute logic only on button pressed
        if (Input.GetButtonDown("Pick"))
        {
            // Check if player picked some item already
            if (pickedItem)
            {
                pickedItem.GetComponent<Collider>().isTrigger = false;
                // If yes, drop picked item
                DropItem(pickedItem);
            }
            else
            {
                RaycastHit hit;
                // If no, try to pick item in front of the player
                if (Physics.Raycast(characterCamera.transform.position, characterCamera.transform.forward, out hit))
                {

                    var Hit = hit.transform.GetComponent<PickableItem>();
                    if (Hit)
                    { 
   
                       // Pick it
                       PickItem(Hit);
                       Hit.GetComponent<Collider>().isTrigger = true;
    
                    }
                }
  
            }
        }
    }

    
    /// <summary>
    /// Method for picking up item.
    /// </summary>
    /// <param name="item">Item.</param>
    private void PickItem(PickableItem item)
    {
        // Assign reference
        pickedItem = item;
        Transform itemTrans = item.transform;
        // Disable rigidbody and reset velocities
        item.Rb.isKinematic = true;
        item.Rb.velocity = Vector3.zero;
        item.Rb.angularVelocity = Vector3.zero;
        // Set Slot as a parent
        item.transform.SetParent(slot);
        // Reset position and rotation
        item.transform.localPosition = Vector3.zero;
        if (item.name.Equals("NinjaBlade"))
        {
            item.transform.localRotation = refer.rotation;
        }else if (item.name.Equals("Knife"))
        {
            item.transform.localPosition = knifePosition.position;
            item.transform.localRotation = knifePosition.rotation;
        }else
        {
            item.transform.localPosition = Vector3.zero;
            item.transform.localRotation = Quaternion.identity;
        }

    }
    /// <summary>
    /// Method for dropping item.
    /// </summary>
    /// <param name="item">Item.</param>
    private void DropItem(PickableItem item)
    {
        // Remove reference
        pickedItem = null;
        // Remove parent
        item.transform.SetParent(null);
        // Enable rigidbody
        item.Rb.isKinematic = false;
        // Add force to throw item a little bit
        item.Rb.AddForce(item.transform.forward * 2, ForceMode.VelocityChange);
    }

}
